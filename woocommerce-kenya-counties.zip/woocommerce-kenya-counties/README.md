# Description

A short plugin that adds Kenyan counties to WooCommerce's list of states. The list is taken from [Wikipedia](https://en.wikipedia.org/wiki/Counties_of_Kenya) - no responsibility for accuracy is made!

# Installation

1. Install the plugin as a normal WordPress plugin
1. Activate the plugin through the 'Plugins' menu in WordPress
1. That's it! The counties will show up in WooCommerce
